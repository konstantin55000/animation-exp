(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_1", frames: [[0,0,970,8]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.arr = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC021D").s().p("EhelAdHIy59EIS99JMDQAAAAIy9dJIS6dEg");
	this.shape.setTransform(0.05,0.05,0.2,0.2,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-145.2,-37.2,290.5,74.5);


(lib.Tween6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#020202").s().p("AmiSEIAAvcIrU0rIOgAAIDmKRIDoqRIN/AAIrUUrIAAPcg");
	this.shape.setTransform(34.8,0.1,0.1664,0.1664,0,0,0,-0.2,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#020202").s().p("AFiSEIhnlhIodAAIhmFhIszAAMAMfgkHIM5AAMAMfAkHgAiXDXIEEAAIiAnbg");
	this.shape_1.setTransform(4.55,0.1,0.1664,0.1664,0,0,0,0.3,0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#020202").s().p("AwiSEMAAAgkHIM6AAQJIAAFeExQFlE3AAIYQAAIUljE7QlgE4pIAAgAj1HvIAxAAQC6AABoh7QBtiBAAj2QAAj1hth/Qhnh4i7AAIgxAAg");
	this.shape_2.setTransform(-30.05,0.1,0.1664,0.1664,0,0,0,-0.3,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.6,-19.1,101.5,38.400000000000006);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DC021D").ss(10).p("EhvSAb/ISL77IyO8CMDNTAAAIR5chIx1bcg");
	this.shape.setTransform(0.05,0.1,0.2,0.2,0,0,0,1.8,0.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-152.1,-40.8,301,81.69999999999999);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC021D").s().p("AoRNBQipiJhGjAIH4kRQA3BdBGA4QBHA5A/AAQAaAAAPgNQAOgNAAgVQAAg3h2g9QimhKhfgzQishbhZhrQh3iQAAjEQAAkZDKirQDJipFIAAQEsAADdCnQBXBCA+BUQA3BKAWBEInwEdQgjhIg2gyQg/g5g/AAQgaAAgQAPQgQAOAAAWQAAA5B3BAQBIAnC+BcQCtBcBaBpQB3CMAAC7QAAEfjOCsQjOCqlcAAQk4AAjciyg");
	this.shape.setTransform(91.6934,-0.0539,0.198,0.198);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DC021D").s().p("ApfPPIAA+dIS/AAIAAIlIoAAAIAAChIHJAAIAAICInJAAIAACwIIAAAIAAIlg");
	this.shape_1.setTransform(63.1118,-0.0539,0.198,0.198);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DC021D").s().p("ApsPPIAA+dILCAAIAAV4IIXAAIAAIlg");
	this.shape_2.setTransform(36.2377,-0.0539,0.198,0.198);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DC021D").s().p("ArNLQQiKiJhIi4QhJi6AAjXQAAjRBMi5QBKi2CLiKQCNiLC+hMQDGhPDnAAQILAAEyE9ImIGoQhOhEhPgjQhdgnhtAAQioAAhtByQhwBzAAC0QAAC+BqB1QBsB2CyAAQBUAABFgSQA0gOAigUIAAhMIjcAAIAAnWINUAAIAANhQihCLi9BNQkFBplPAAQnhAAkjkjg");
	this.shape_3.setTransform(1.7518,-0.0539,0.198,0.198);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DC021D").s().p("ADMPPImnuUIAAOUIq7AAIAA+dILMAAIGmOUIAAuUIK7AAIAAedg");
	this.shape_4.setTransform(-37.9704,-0.0539,0.198,0.198);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DC021D").s().p("AlhPPIAA+dILDAAIAAedg");
	this.shape_5.setTransform(-66.6311,-0.0539,0.198,0.198);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DC021D").s().p("AoSNBQioiKhFi/IH4kRQA2BdBFA4QBIA5A/AAQAaAAAPgNQAOgNAAgVQAAg3h2g9QimhKhfgzQirhbhahrQh3iQAAjEQAAkZDKirQDJipFIAAQErAADdCnQBYBCA+BUQA3BKAVBEInvEdQgjhJg3gxQg+g5g+AAQgbAAgQAPQgQAOAAAWQAAA5B3BAQBIAnC+BcQCtBcBaBpQB3CMAAC7QAAEfjOCsQjOCqldAAQk3AAjdiyg");
	this.shape_6.setTransform(-90.8871,-0.0539,0.198,0.198);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.1,-20,213,40);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC021D").s().p("AkLGtIAAtZIIXAAIAADxIjiAAIAABHIDKAAIAADiIjKAAIAABOIDiAAIAADxg");
	this.shape.setTransform(44,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DC021D").s().p("AibGtIAApoIioAAIAAjxIKHAAIAADxIipAAIAAJog");
	this.shape_1.setTransform(31.1,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DC021D").s().p("AjoFvQhLg9gehUIDeh5QAYApAeAaQAgAYAcAAQAKAAAHgFQAGgGAAgKQAAgYgzgbQhJgggqgXQiohXAAiUQAAh8BZhLQBZhLCQAAQCDAABiBKQBNA5AWBHIjaB9QgPgfgYgWQgcgZgbAAQgMAAgHAHQgHAFAAAKQAAAZA0AdQAgARBUAoQCoBZAACNQAAB/hbBLQhaBLiaAAQiIAAhhhOg");
	this.shape_2.setTransform(17.15,0.05,0.2,0.2,0,0,0,0.1,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DC021D").s().p("AkLGtIAAtZIIXAAIAADxIjiAAIAABHIDKAAIAADiIjKAAIAABOIDiAAIAADxg");
	this.shape_3.setTransform(4.5,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DC021D").s().p("AlgGtIAAtZIFzAAQCRAABXBDQBVBCAABsQAABrhZA+QAyAZAcAzQAcAwAAA3QAAB/hYBIQhUBFiPAAgAg1DGIA1AAQAYAAARgRQARgQAAgYQAAgYgRgRQgRgRgYAAIg1AAgAg1hoIA1AAQAXAAAOgOQAMgOAAgTQAAgUgMgNQgNgPgYAAIg1AAg");
	this.shape_4.setTransform(-8.7,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DC021D").s().p("AkLGtIAAtZIIXAAIAADxIjiAAIAABHIDJAAIAADiIjJAAIAABOIDiAAIAADxg");
	this.shape_5.setTransform(-27.25,0.05,0.2,0.2,0,0,0,0.4,0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DC021D").s().p("AmIGtIAAtZIEzAAQDYAACBBxQCFB0AADHQAADEiEB1QiCB0jYAAgAhaC3IASAAQBFAAAmgtQAogwAAhaQAAhbgogwQgmgshFAAIgSAAg");
	this.shape_6.setTransform(-41.4,0.05,0.2,0.2,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.3,-8.9,98.69999999999999,17.8);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmIGtIAAtZIEzAAQDYAACBBxQCFB0AADHQAADEiEB1QiCB0jYAAgAhaC3IASAAQBFAAAmgtQApgwAAhaQAAhbgpgwQglgshGAAIgSAAg");
	this.shape.setTransform(45.05,0.05,0.2,0.2,0,0,0,0.2,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABZGtIi5mTIAAGTIk0AAIAAtZIE7AAIC6GTIAAmTIEzAAIAANZg");
	this.shape_1.setTransform(27.7,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ACDGtIgmiDIjIAAIgmCDIkwAAIEptZIExAAIEpNZgAg4BQIBgAAIgviwg");
	this.shape_2.setTransform(10.3,0.05,0.2,0.2,0,0,0,0.2,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AibGtIAApoIioAAIAAjxIKHAAIAADxIipAAIAAJog");
	this.shape_3.setTransform(-2.8,0.05,0.2,0.2,0,0,0,0.2,0.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AjoFvQhLg9gfhUIDfh5QAYApAfAaQAeAYAcAAQALAAAHgFQAGgGAAgKQAAgYg0gbQhIgggqgXQinhXAAiUQgBh8BahLQBYhLCQAAQCEAABhBKQBNA5AWBHIjaB9QgQgfgXgWQgcgZgbAAQgMAAgHAHQgHAFAAAKQAAAZA1AdQAfARBUAoQCoBZAACNQAAB/hbBLQhaBLiaAAQiJAAhghOg");
	this.shape_4.setTransform(-16.25,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AkJGtIAAtZIITAAIAADxIjeAAIAABjIDJAAIAADlIjJAAIAAEgg");
	this.shape_5.setTransform(-28.65,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ACDGtIgmiDIjIAAIgmCDIkwAAIEptZIExAAIEpNZgAg3BQIBgAAIgwiwg");
	this.shape_6.setTransform(-43.65,0.05,0.2,0.2,0,0,0,0.4,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.8,-8.9,105.69999999999999,17.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AibGtIAApoIioAAIAAjxIKHAAIAADxIipAAIAAJog");
	this.shape.setTransform(17.2,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkLGtIAAtZIIXAAIAADxIjiAAIAABHIDJAAIAADiIjJAAIAABOIDiAAIAADxg");
	this.shape_1.setTransform(4.15,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ADeGtIAAmdIhVFcIkRAAIhVlcIAAGdIkuAAIAAtZIGFAAICGHmICHnmIGFAAIAANZg");
	this.shape_2.setTransform(-13.05,0.05,0.2,0.2,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.6,-8.6,47.3,17.2);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0A1QgVgWAAgfQAAgeAWgWQAVgWAeAAQAeAAAWAWQAWAWAAAeQAAAfgWAWQgVAWgfAAQgeAAgWgWgAgpgrQgTASABAZQAAAaARASQASASAYAAQAZAAASgSQASgSAAgaQAAgZgSgSQgSgSgZAAQgYAAgRASgAASApIgNghIgSAAIAAAhIgRAAIAAhQIAkAAQAeAAAAAYQAAAPgOAFIAOAkgAgNgEIARAAQAOAAAAgMQAAgKgNAAIgSAAg");
	this.shape.setTransform(795.85,21.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhIBeQgKAAgGgIQgHgIACgMIAZiNQACgHAGgGQAGgFAHAAIB4AAQAJAAAHAIQAGAHgBAKIgaCOQgCAIgGAGQgGAGgHAAg");
	this.shape_1.setTransform(300.7165,24.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AN5IUQhHgOg7g/Qg6g+gOhMQgHgmAAgrQgFAFgJAAIn0AAIgBAHQAAAJAGAUIACAHQASAtAoAaQAnAZAxgBQBhgCBPhbQAGgHAKAAIBwAAQALAAAGAKQAHAKgFALQgwBlhhA+QhiA/hwAAQhNgDg/glQg+glglhAQgkhEABhcIgwENQgEANgMAAIiCAAQgIAAgEgGQgDgFAAgFIAAgEQAgiGApj/QAtkRAIgnQhDBRnLJ6QgFAGgHAAIiGAAQgIAAgFgGQgDgFAAgFIAAgEQAeiLArj7IA2k2QhBBPooJ7QgFAGgIAAIivAAQgKAAgEgLQgEgJAGgIINnv6QAFgGAHAAICJAAQAIAAAEAGQAEAEAAAGIAAADQheIigUBjQBFhPG3pDQAFgGAGAAICNAAQAHAAAFAGQAFAGgCAIIhnI8IADgGQAxhgBehCQBchABngNIACAAQBcgEBGAiQBGAjAqBIIABABQAjBHAEBUQAjhpBXhQQBIhFBXgaQBWgbBYAUIAEABIALAFIAoATQAXANAQAOIAyj1QACgHAGgFQAFgFAIAAIBsAAQAKAAAGAIQAHAIgCAJIieNmQgDAOgSAAIhsAAQgNAAgDgFQgFgFAAgIIAAgEIAFgYQhpBBhkAAQgcAAgbgEgAQBgZQgqAJghAWQg6AsgfA3QggA3AAA7QAAAVAEASQAGAdAPAZQARAbAXAQQA0AiBXgSQA8gOA0g2QA0g2ARhBQAGgXAAgYQACg0gXgmQgkg5g5gOQgVgFgVAAQgUAAgTAEgAIZBUQgEglgkglQgYgUgYgIQgdgKgtADQgwAHgrAaQgvAfgXAtIFDAAIAAAAg");
	this.shape_2.setTransform(145.2184,54.1472);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ADVHHQgDAAgHgEQgFAEgCAAIiDAAQgLAAgGgJQh+jWgrhDIgeCqQgSBhgDAIQgEAPgQAAIh1AAQgKAAgGgIQgGgHABgJIBZoWIgJABIgJABQh3ARggB6IhPGQQgCAIgFAEQgGAFgIAAIhoAAQgKAAgHgHQgGgIACgJIB3qVQADgQASAAIBsAAQAKAAAGAHQAGAHgBAKIgDAQQAfgVAlgMQAogOAkgBQAJAAAHAIIABABQAQhhAThfQACgHAGgFQAFgFAIAAIB3AAQAKAAAGAIQAFAFAAAIIAAAEQg0EWgRBkQA6g/Bgh9QAGgHAKAAICLAAQALAAAGAJQAGgJAMAAIBDAAIAji+QABgIAGgFQAGgFAIAAIB4AAQALAAAFAIQAFAFAAAIIAAAEIgiC3IB6AAQAKAAAGAHQAFAGAAAIIgSBvQgCAIgFAEQgGAFgIAAIiDABIhhIWQgBAHgGAFQgGAFgHAAgAAPBEIDGFJQALhDAmjQIAojbIg7AAQgKAAgGgHQgGgIABgKIAPhSIjeEQg");
	this.shape_3.setTransform(732.8015,60.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Aq8IDQBKgdBGguQAjgXAUgQQB5hsALiPQAKiOhmhHQAKAMAFANQBOBggvCEQgvCIiQBGQgXAMgmAMQhNAahOAJQg2gjgrguQBLAKBOgFQAngBAYgFQCeggBQh2QBOh1g1hxIABAGQAAAIgCAHQAYB9hpBeQhsBfiigMQgYgCgmgIQhMgQhFgdQghg8gQhDIgDgLQA8AvBFAkQAjASAXAIQCXA1B/g9QB9g8AMh8QgEAKgKAMQgsB1iHAZQiLAZiEhaQgXgSgggeQhBg5gsg1IhfIJQgCAOgSAAIhsAAQgMAAgFgHQgEgFAAgGIAFgdQiGBVh+gYQhIgNg6g/Qg7g+gNhNQgDgQgCgjIgDggIgwEOQgCAOgSAAIh5AAQgMAAgEgFQgGgHACgLIB3qWQACgHAGgFQAFgFAIAAIB4AAQAKAAAHAHQAGAIgCAKIgxENIACgEQAlhrBThPQBJhFBXgaQBXgaBXAVIAQAFQA1AXAZAXQACgQAEgNIADgJQAIgQAPAAIBtAAQALAAAGAFQAGAGACAJQAYBFAtBMQAXAlASAYQBrB+CQAIQCNAJBFhtIgSAMIAAAAQheBZiHgtQiKguhIiVQgKgXgNgmQgYhKgKhNQAmhBA2g1QgKBOAEBRQACAoAEAYQAfCjB3BQQB1BPBxg4QgIABgJAAIgKAAQh7AYhchrQhdhsALilQACgZAIgoQARhPAdhIQA5gfA/gRQguA9gjBHIgaA5Qg1CeA/CCQA/CAB+AHQgIgEgHgFIgCgBIgBAAQh6gngdiMQgeiQBciLIApgyQA1g9A9gvQBMAABIAXQhJAdhEAuIg2AmQh8BtgICSQgJCPBqBFQgIgKgFgKQhVhfAtiJQAtiJCThJIA/gYQBOgaBOgKQA7AmAxA0QhOgNhSAFIhCAHQigAfhQB5QhOB3A4ByIgBgOIABgKQgah+BphfQBshgCjALIBDALQBQATBJAgQAeA4ARBCIAFAUQg/gzhKgnIg/gdQiXg1h/A9Qh9A8gMB9QAGgOAJgLQAth0CHgXQCKgaCDBbIA1AsQA+A5AuBAQgCBCgTA/QgchKgshFIgng1Qhph7iMgLQiKgMhIBlQAIgFAMgEQBfhSCEAvQCGAvBGCSIAfBUQAgBjAIBOILZtYQAFgFAHAAICYAAQAHAAAFAFQAEAGAAAGIgBADQhaIjgZBiQBFhQGzpEQAFgFAHAAICRAAQAIAAAFAFQAEAIgCAHIhsJMQAmhYBHhCQBJhFBWgZQBWgbBZAUIAEABIALAFQAxATAiAeIAIgpQABgIAGgEQAGgFAHABIBtAAQALAAAFAGQAFAHAAAIIgXCOIhiIMQgCAOgSAAIhsAAQgNAAgDgFQgFgGAAgHIAFgdQiGBVh+gYQhIgNg6g/Qg7g+gNhNQgDgPADgZQAFghAAgIIAAgSIgxEfQgBAFgFAEQgEAEgFAAIiFAAQgGAAgGgHQgDgEAAgFIAAgFQAYh3AskDQApjvANg+QgqAyj0FHIjsE9QgFAGgHAAIiGAAQgIAAgFgGQgDgFAAgFIAAgEQAaiFArj3IA0ksQhBBPo0JnQgFAGgHAAIisAAQgKAAgEgKQgDgIAEgHIAAgBIABgBIgBABIAQgbQARghAIglQALhLgHhSIgKhCQgfifhzhQQhxhQhwAyIAFAAQALAAAJACQB5gUBZBrQBbBsgLCiIgLBDQgRBRgfBKQg3Aeg8APIgTADQAzg+AmhMQATgmAJgZQA1idhAiDQg/h/h/gHQALAEAJAGQB6AoAdCMQAeCPhcCKQgPAXgcAeQg4BAhAAwQhIgEhIgYgAZHgaQgqAJghAWQg5AsgeA3QgfA3AAA7QAAAQAEAWQAQBBAtAhQAyAgBVgOQA7gPA1g3QA1g2AThBQAHgUAAgeQAAgygVgmQgfg2hBgQQgUgFgWAAQgTAAgUAEgA2hgaQgqAJghAWQg5AsgeA3QgfA3AAA7QAAAVAEARQATBEAqAeQAYAPAkAEQAmAFAsgJQA7gOAyg2QAyg1AShBQAHgYAAgaQAAgygVgmQgfg2hBgQQgUgFgWAAQgTAAgUAEg");
	this.shape_4.setTransform(477.8373,54.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,803.3,108.5), null);


(lib.arrowcopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(5).p("AhAiGIBzCFIhzCI");
	this.shape.setTransform(4.9941,14.9861);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowcopy, new cjs.Rectangle(-4,-1,17.4,32), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#323233").ss(5).p("AhAiGIBzCFIhzCI");
	this.shape.setTransform(4.9941,14.9861);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-4,-1,17.4,32), null);


(lib.back_arr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.arr();
	this.instance.setTransform(-553,-2);

	this.instance_1 = new lib.arr();
	this.instance_1.setTransform(-447.5,-2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-553,-2,1075.5,8);


(lib.ctaBack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Eh1LhSBMDqXAAAMAAACkDMjqXAAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Eh1LBSCMAAAikDMDqXAAAMAAACkDg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-751,-526,1502,1052);


(lib.txt1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_8
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(-360.55,8.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({x:49.45,alpha:1},24,cjs.Ease.quartOut).wait(3).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_7
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-278.9,8.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({_off:false},0).to({x:131.1,alpha:1},24,cjs.Ease.quartOut).wait(6).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_6
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(-169.4,8.9);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:240.6,alpha:1},24,cjs.Ease.quartOut).wait(9).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_5
	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.setTransform(-109.65,62.2);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:170.35,alpha:1},24,cjs.Ease.quartOut).wait(9).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_4
	this.instance_4 = new lib.Tween5("synched",0);
	this.instance_4.setTransform(-109.25,62.15,1.8325,1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(3).to({_off:false},0).to({scaleX:1,x:170.75,alpha:1},24,cjs.Ease.quartOut).wait(6).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_1
	this.instance_5 = new lib.Tween6("synched",0);
	this.instance_5.setTransform(462.1,141.1);
	this.instance_5.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:152.1,alpha:1},24,cjs.Ease.quartOut).wait(9).to({startPosition:0},0).to({_off:true},1).wait(8));

	// Layer_2
	this.instance_6 = new lib.Tween7("synched",0);
	this.instance_6.setTransform(455.35,141.1,1.8984,1,0,0,0,0.1,0);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).to({regX:0,scaleX:1,x:145.25,alpha:1},24,cjs.Ease.quartOut).wait(6).to({startPosition:0},0).to({_off:true},1).wait(8));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.3,0,1122.2,178.4);


(lib.Arrs2copy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(28));

	// _Clip_Group_
	this.instance = new lib.arrowcopy();
	this.instance.setTransform(3.7,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:29,alpha:0},9,cjs.Ease.quadIn).wait(3).to({x:-16.3},0).to({x:3.7,alpha:1},10,cjs.Ease.quartOut).wait(5));

	// _Clip_Group_
	this.instance_1 = new lib.arrowcopy();
	this.instance_1.setTransform(-2.45,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({x:23.85,alpha:0},9,cjs.Ease.quadIn).wait(4).to({x:-15.15},0).to({x:-2.45,alpha:1},10,cjs.Ease.quartOut).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-7,53,14.2);


(lib.Arrs2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(28));

	// _Clip_Group_
	this.instance = new lib.arrow();
	this.instance.setTransform(3.7,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:29,alpha:0},9,cjs.Ease.quadIn).wait(3).to({x:-16.3},0).to({x:3.7,alpha:1},10,cjs.Ease.quartOut).wait(5));

	// _Clip_Group_
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(-2.45,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({x:23.85,alpha:0},9,cjs.Ease.quadIn).wait(4).to({x:-15.15},0).to({x:-2.45,alpha:1},10,cjs.Ease.quartOut).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-7,53,14.2);


(lib.Arrscopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_27 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(27).call(this.frame_27).wait(1));

	// _Clip_Group_
	this.instance = new lib.arrowcopy();
	this.instance.setTransform(3.7,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:29,alpha:0},9,cjs.Ease.quadIn).wait(3).to({x:-16.3},0).to({x:3.7,alpha:1},10,cjs.Ease.quartOut).wait(5));

	// _Clip_Group_
	this.instance_1 = new lib.arrowcopy();
	this.instance_1.setTransform(-2.45,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({x:23.85,alpha:0},9,cjs.Ease.quadIn).wait(4).to({x:-15.15},0).to({x:-2.45,alpha:1},10,cjs.Ease.quartOut).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-7,53,14.2);


(lib.Arrs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_27 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(27).call(this.frame_27).wait(1));

	// _Clip_Group_
	this.instance = new lib.arrow();
	this.instance.setTransform(3.7,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:29,alpha:0},9,cjs.Ease.quadIn).wait(3).to({x:-16.3},0).to({x:3.7,alpha:1},10,cjs.Ease.quartOut).wait(5));

	// _Clip_Group_
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(-2.45,0,0.4444,0.4444,0,0,0,6.4,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({x:23.85,alpha:0},9,cjs.Ease.quadIn).wait(4).to({x:-15.15},0).to({x:-2.45,alpha:1},10,cjs.Ease.quartOut).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-7,53,14.2);


(lib.cta2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.Arr = new lib.Arrs2copy();
	this.Arr.name = "Arr";
	this.Arr.setTransform(73.65,0.35,0.7059,0.7059);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgUAqIAAhTIAKAAIAABKIAfAAIAAAJg");
	this.shape.setTransform(43.55,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIAmAAIAAAJIgdAAIAAAcIAaAAIAAAIIgaAAIAAAdIAeAAIAAAJg");
	this.shape_1.setTransform(37.85,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAQAqIgigqIAAAqIgJAAIAAhTIAJAAIAAAmIAhgmIAMAAIgjAoIAkArg");
	this.shape_2.setTransform(31.825,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAXAqIgthEIAABEIgKAAIAAhTIAKAAIAtBDIAAhDIAKAAIAABTg");
	this.shape_3.setTransform(23.825,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAqIAAhTIAJAAIAABTg");
	this.shape_4.setTransform(18.175,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAUAqIgUhFIgTBFIgLAAIgYhTIALAAIATBHIAUhHIAJAAIAVBHIAThHIAKAAIgYBTg");
	this.shape_5.setTransform(11.1,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTAqIAAhTIAmAAIAAAJIgdAAIAAAcIAaAAIAAAIIgaAAIAAAdIAeAAIAAAJg");
	this.shape_6.setTransform(-0.3,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeAqIAAhTIARAAQAUAAAMALQAMALAAATQAAAUgMAMQgMAKgUAAgAgVAhIAKAAQAOAAAJgIQAJgJAAgQQAAgPgJgIQgJgJgOAAIgKAAg");
	this.shape_7.setTransform(-6.875,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAXAqIgthEIAABEIgKAAIAAhTIAKAAIAtBDIAAhDIAKAAIAABTg");
	this.shape_8.setTransform(-18.225,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAqIAAhTIAJAAIAABTg");
	this.shape_9.setTransform(-23.875,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgXAqIAAhTIAXAAQAKAAAIAGQAGAHAAALQAAALgHAGQgHAHgKAAIgOAAIAAAjgAgOgBIANAAQAGAAAFgEQAEgFAAgHQAAgHgEgEQgEgFgHABIgNAAg");
	this.shape_10.setTransform(-31.1,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdAfQgNgNAAgSQAAgRANgNQAMgMARAAQASAAANAMQAMANAAARQAAASgMANQgNAMgSAAQgRAAgMgMgAgWgXQgKAJAAAOQAAAPAKAJQAJALANgBQAOABAKgLQAJgJAAgPQAAgOgKgJQgJgKgOAAQgNAAgJAKg");
	this.shape_11.setTransform(-39.225,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgUAqIAAhTIAKAAIAABKIAfAAIAAAJg");
	this.shape_12.setTransform(-49.4,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAbAqIgKgbIggAAIgKAbIgKAAIAfhTIAJAAIAfBTgAgMAGIAaAAIgOgkg");
	this.shape_13.setTransform(-56.175,0.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAbAqIgKgbIggAAIgKAbIgKAAIAfhTIAJAAIAfBTgAgMAGIAaAAIgOgkg");
	this.shape_14.setTransform(-63.725,0.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAXAqIAAgmIgsAAIAAAmIgKAAIAAhTIAKAAIAAAlIAsAAIAAglIAJAAIAABTg");
	this.shape_15.setTransform(-71.65,0.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(1,1,1).p("AtlBzIAAjmQAAgTAUAAIWHAAIAXAAIAAENIAAAAIgXAAI2HAAQgTAAgBgUANlBzIAAjmQgBgTgSAAIjwAAIAAENIAAAAID1AAQAPgDgBgR");
	this.shape_16.setTransform(-0.9984,0.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AtRCHQgTAAAAgTIAAgBIAAjlQAAgUATAAIWHAAIAXAAIAAABIgXgBIAXABIAAEMIgXAAgAJiCHIAAAAIAAkNIDwAAQAUAAgBAUIAAgBQgCgSgQAAIAAAAIgBAAIjwAAIAAEMIAAkMIDwAAIABAAIAAAAQAQAAACASIAAABIAADlIAAABQAAATgTAAgANlhyIAAAAgANlhyIAAAAg");
	this.shape_17.setTransform(-1,0.5375);

	this.Arr_1 = new lib.Arrscopy();
	this.Arr_1.name = "Arr_1";
	this.Arr_1.setTransform(73.65,0.35,0.7059,0.7059);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#303030").s().p("AtRCHQgTAAAAgTIAAgBIAAjlQAAgUATAAIWHAAIAXABIAAEMIgXAAgAJiCHIAAkMIDwAAQASgBABAUIAADlIAAABQAAATgTAAg");
	this.shape_18.setTransform(-1,0.5375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AhrCHIAAkNIDvAAQAUAAgBAUQgBgUgSABIjvAAIAAEMgAiXiFIAXgBIAAABg");
	this.shape_19.setTransform(70.8,0.525);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AuViIIcrAAIAAERI8rAAg");
	this.shape_20.setTransform(-0.475,0.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AuVCJIAAkRIcrAAIAAERg");
	this.shape_21.setTransform(-0.475,0.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.Arr}]}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.Arr_1}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.3,-14.6,185.7,29.7);


(lib.cta1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.Arr = new lib.Arrs2();
	this.Arr.name = "Arr";
	this.Arr.setTransform(73.65,0.35,0.7059,0.7059);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgZAiQgJgKAAgPIAAgzIAUAAIAAAzQAAAHAEAEQAEAEAGAAQAHAAAEgEQAEgEAAgHIAAgzIAUAAIAAAzQAAAPgJAJQgKAKgQAAQgQAAgJgJg");
	this.shape.setTransform(8.775,1.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAPAqIgdgyIAAAyIgVAAIAAhTIAVAAIAeAzIAAgzIAUAAIAABTg");
	this.shape_1.setTransform(0.25,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAqIAAhTIAVAAIAABAIAYAAIAAATg");
	this.shape_2.setTransform(-8.875,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgWAqIAAhTIAsAAIAAASIgXAAIAAAPIATAAIAAARIgTAAIAAAOIAYAAIAAATg");
	this.shape_3.setTransform(-14.675,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgJAqIAAhBIgSAAIAAgSIA3AAIAAASIgSAAIAABBg");
	this.shape_4.setTransform(-20.775,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgLApQgGgCgDgDIgFgGIgDgHIARgIQACAEADACQADADAEAAQAHAAABgFQAAgDgDgCQgDgDgDgBIgIgEIgJgFQgDgDgDgEQgCgGgBgFQABgMAHgGQAIgIALABQAGAAAFABQAGADACADIAGAGIACAGIgRAIIgCgEIgDgDQgDgCgDABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABQAAADAEACIAIAGIAKAEQAFADAEAEQADAGAAAHQAAAMgIAHQgIAIgNgBQgGAAgFgCg");
	this.shape_5.setTransform(-27.05,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgWAqIAAhTIAsAAIAAASIgXAAIAAAPIATAAIAAARIgTAAIAAAOIAYAAIAAATg");
	this.shape_6.setTransform(-32.925,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAqIAAhTIAdAAQANAAAHAGQAHAGAAAKQAAAGgDAFQgCAEgEADQAMAEAAAOQAAAMgIAHQgJAGgMAAgAgJAYIAJAAQAFAAABgCQACgDAAgEQAAgDgCgCQgBgDgFAAIgJAAgAgJgIIAJAAQADAAACgDQABgCAAgDQAAgEgBgCQgCgBgDAAIgJAAg");
	this.shape_7.setTransform(-39.25,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FAA332").s().p("AJiCHIAAkNIDwAAQAUAAgBAUIAADlQABAUgUAAgAtRCHQgTAAAAgUIAAjlQAAgUATAAIWeAAIAAENg");
	this.shape_8.setTransform(-1,0.525);

	this.Arr_1 = new lib.Arrs();
	this.Arr_1.name = "Arr_1";
	this.Arr_1.setTransform(73.65,0.35,0.7059,0.7059);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E39126").s().p("AJiCHIAAkNIDwAAQAUAAgBAUIAADlQABAUgUAAgAtRCHQgTAAAAgUIAAjlQAAgUATAAIWeAAIAAENg");
	this.shape_9.setTransform(-1,0.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AuViMIcrAAIAAEZI8rAAg");
	this.shape_10.setTransform(-0.475,0.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AuVCNIAAkZIcrAAIAAEZg");
	this.shape_11.setTransform(-0.475,0.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.Arr}]}).to({state:[{t:this.shape_9},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.Arr_1}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.3,-14.9,185.7,30.1);


(lib.arr_red = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back_arr("synched",0);
	this.instance.setTransform(-37.5,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:14.5},30).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-590.5,0,1127.5,8);


// stage content:
(lib._970x250 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,71];
	// timeline functions:
	this.frame_0 = function() {
		var border = new createjs.Shape();
		border.graphics.beginStroke("#999999").setStrokeStyle(2).drawRect(0, 0, lib.properties.width, lib.properties.height);
		stage.addChild(border);
		stage.enableMouseOver(20);
		if (this.eventsAdded == undefined) {
			this.eventsAdded = true;
			this.cta1.addEventListener("mousedown", clickTag1.bind(this));
			this.cta2.addEventListener("mousedown", clickTag2.bind(this));
			this.ctaBack.addEventListener("mousedown", clickTagBack.bind(this));
		}
	}
	this.frame_71 = function() {
		this.loopTotal = 1;
		if (this.loopIndex == undefined) this.loopIndex = 0;
		this.loopIndex++;
		if (this.loopIndex >= this.loopTotal) this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71).call(this.frame_71).wait(1));

	// logo
	this.instance = new lib.logo();
	this.instance.setTransform(88.35,223.25,0.17,0.17,0,0,0,402.1,54.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(72));

	// cta2
	this.cta2 = new lib.cta2();
	this.cta2.name = "cta2";
	this.cta2.setTransform(935,203,1.3031,1.3031);
	this.cta2.alpha = 0;
	new cjs.ButtonHelper(this.cta2, 0, 1, 2, false, new lib.cta2(), 3);

	this.timeline.addTween(cjs.Tween.get(this.cta2).wait(35).to({x:835,alpha:1},11,cjs.Ease.quartOut).wait(26));

	// cta1
	this.cta1 = new lib.cta1();
	this.cta1.name = "cta1";
	this.cta1.setTransform(925,161,1.3031,1.3031);
	this.cta1.alpha = 0;
	new cjs.ButtonHelper(this.cta1, 0, 1, 2, false, new lib.cta1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.cta1).wait(37).to({x:835,alpha:1},11,cjs.Ease.quartOut).wait(24));

	// ctaBack
	this.ctaBack = new lib.ctaBack();
	this.ctaBack.name = "ctaBack";
	this.ctaBack.setTransform(485,125);
	new cjs.ButtonHelper(this.ctaBack, 0, 1, 2, false, new lib.ctaBack(), 3);

	this.timeline.addTween(cjs.Tween.get(this.ctaBack).wait(72));

	// Layer_3
	this.instance_1 = new lib.arr_red();
	this.instance_1.setTransform(485,3,1,1,0,0,180,0,2);

	this.instance_2 = new lib.arr_red();
	this.instance_2.setTransform(485,245,1,1,0,0,0,0,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(72));

	// txt1
	this.instance_3 = new lib.txt1("synched",0,false);
	this.instance_3.setTransform(485,124.6,1.04,1.04,0,0,0,157.4,89.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(38).to({_off:false},0).wait(34));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(219,-276,1017,927);
// library properties:
lib.properties = {
	id: 'BD10522D48EC93478BD7181F5494F048',
	width: 970,
	height: 250,
	fps: 30,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"index_atlas_P_1.png", id:"index_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BD10522D48EC93478BD7181F5494F048'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;